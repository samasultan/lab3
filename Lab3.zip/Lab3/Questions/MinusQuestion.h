//
//  MinusQuestion.h
//  Lab3
//
//  Created by user169313 on 2021-07-10.
//

#import "Question.h"

NS_ASSUME_NONNULL_BEGIN

@interface MinusQuestion : Question

- (instancetype)init;

@end

NS_ASSUME_NONNULL_END
